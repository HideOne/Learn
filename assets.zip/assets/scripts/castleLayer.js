// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html
// 模拟数据
var info = {
    user: {
        headUrl: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1810152264,2923293270&fm=27&gp=0.jpg",
        name: "手术室打酱油的路过",
        sex: 0
    },
    time:{
        level: "城堡时代IV",
        needExp: 1000,
        nowExp: 100,
        next_build: 1,
        buildname: "伐木场",
        info: "扎实大所多撒多撒多撒多撒多撒多撒多撒多撒多撒多撒多卡死了的撒打算开房间卡"
    },
    army: {
        power: 999,
        list: [66, 77, 99, 11, 22],
    },
    res: {
        ability: 333,
        list: [44, 55, 11, 22, 33, 66]
    }
}
////////////////////

cc.Class({
    extends: cc.Component,

    properties: {

        userName: { // 玩家姓名
            default: null,
            type: cc.Label
        },

        usersex: { // 玩家姓性别
            default: null,
            type: cc.Sprite
        },

        userHead: { // 玩家头像
            default: null,
            type: cc.Sprite
        },
    
        timeLevelLabel: { // 时代等级
            default: null,
            type: cc.Label
        },
        expBar: { // 勋章进度条
            default: null,
            type: cc.ProgressBar
        },
        progressLabel: { // 勋章数量显示
            default: null,
            type: cc.Label
        },
        buildName: { // 建筑名称
            default: null,
            type: cc.Label
        },
        buildImg: { // 建筑图片
            default: null,
            type: cc.Sprite
        },
        buildInfo: { // 建筑描述
            default: null,
            type: cc.Label
        },
        armyPower: { // 军队战斗力
            default: null,
            type: cc.Label
        },
        armyList: [cc.Label],  // 军队数量列表
        resAbility: { // 生产力
            default: null,
            type: cc.Label
        },
        resList: [cc.Label], // 个资源生产力

    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.on(cc.Node.EventType.TOUCH_END, function(){});

        this._loadData(info);
    },

    _getConfig () {

    },

    _loadData (data) {
        if(!data) {
            return;
        }

        // 设置用户的数据
        this.userName.string = cc.requireUtil.Assistant.str_leave_8(data.user.name);
        // this.userHead = 
        cc.requireUtil.Assistant.set_net_Image(data.user.headUrl, null, this.userHead)
        cc.requireUtil.Assistant.set_sex(this.usersex, data.user.sex);

        // 设置时代数据
        this.timeLevelLabel.string = data.time.level;
        this.expBar.progress = data.time.nowExp / data.time.needExp;
        this.progressLabel.string = data.time.nowExp +  "/" + data.time.needExp;
        cc.requireUtil.Assistant.load_local_Image(null);
        this.buildName.string = data.time.buildname;
        this.buildInfo.string = data.time.info;

        // 部队数据
        this.armyPower.string = this.armyPower.string.replace(/xxx/, data.army.power + "");
        for(var i in this.armyList) {
            this.armyList[i].string = data.army.list[i] | "null" + "" ;
        }

        // 资源数据
        this.resAbility.string = this.resAbility.string.replace(/xxx/, data.res.ability + "");
        for(var i in this.resList) {
            this.resList[i].string = data.res.list[i] | "null" + "" ;
        }



    },

    onShop: function () {
        cc.requireUtil.Assistant.log("=========shop==========");
    },


    // start () {

    // },
    onExit () {
        this.node.targetOff(this);
        this.node.destroy();
    }

    // update (dt) {},
});

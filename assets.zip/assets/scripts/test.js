// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:
    onWar () {
        var callfun = function (node) {
            node.name = "warLayer";
        }

        // 开启碰撞检测
        cc.director.getCollisionManager().enabled = true;

        cc.requireUtil.Assistant.add_prefab_2_Node("prefabs/warLayout", cc.director.getScene(), callfun);
    },

    onLoad () {
        var _this = this;
        // cc.loader.loadRes("atlas/main", cc.SpriteAtlas,function(completeCount, totalCount, res){
        cc.loader.loadResDir("atlas", cc.SpriteAtlas,function(completeCount, totalCount, res){
                // console.log('initFrameCache 第 ' + completeCount + '加载完成！' + "======totalCount======="+totalCount);
            }, function (err, atlas,urls) {
            console.log('======initFrameCache==== +加载完成！');
        });
    },
    onCastle () {
        // cc.loader.loadRes("prefabs/castleLayout", function (err, prefab){
        //     if(err){
        //         console.log(err);
        //     }else {
        //         var newNode = cc.instantiate(prefab);
        //         cc.director.getScene().addChild(newNode);
        //     }
        // })
        cc.requireUtil.Assistant.add_prefab_2_Node("prefabs/castleLayout")
    }

    // start () {

    // },

    // update (dt) {},
});

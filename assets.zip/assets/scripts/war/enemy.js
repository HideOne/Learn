// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html


cc.Class({
    extends: cc.Component,

    properties: {
        sprite_build: {
            default: null,
            type: cc.Sprite
        },
        label_user_name: { // 玩家名称
            default: null,
            type: cc.Label
        },
        label_time_level: { // 时代等级
            default: null,
            type: cc.Label
        },
        label_power: { // 战斗力
            default: null,
            type: cc.Label
        },
    },

    onLoad () {

    },

    // 第一次显示不显示战力
    init_data (info) {

        this.user_name = info.user_name;
        this.time_level = info.time_level;
        this.power = info.power;
        this.label_user_name.string = cc.requireUtil.Assistant.str_leave_8(this.user_name);
        this.label_time_level.string = cc.requireUtil.Assistant.level_2_timestr(this.time_level);
        // if()
        this.label_power.string = "战力: ?";
    },

    // 显示战力
    show_power () {
        this.label_power.string =  this.label_power.string.replace(/\?/, this.power+"");

    },
    reset_show_power () {
        this.is_show_power = false;
    },

    onSelect () {
        cc.requireUtil.Assistant.log("onSelect",  "onSelect");
        this.node.zIndex = 2;
        this.scale_and_move_action();
    },

    scale_and_move_action() {
        var move = cc.moveTo(1, cc.p(0, 0));
        var scale = cc.scaleTo(1, 2);
        var _this = this;
        var warLayer = cc.director.getScene().getChildByName("warLayer");
        // 展示云彩的时候同时加载战场
        var load_war_land_fun = function () {
            cc.requireUtil.Assistant.add_prefab_2_Node("prefabs/BattlefieldLayout", warLayer);
        };

        // 动画播放完毕后 播放 云彩
        var fun = cc.callFunc(function () {
            cc.requireUtil.Assistant.log("call fun success", "scale_and_move_action")
            cc.requireUtil.Assistant.open_cloud(this, load_war_land_fun);
        }, this);

        var spawn = cc.spawn(move, scale);
        var seq = cc.sequence(spawn, fun);
        this.node.runAction(seq);
    }

});

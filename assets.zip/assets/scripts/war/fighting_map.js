// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        prefab_soilder: { // 拖动的士兵
            default: null,
            type: cc.Prefab
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {
    //     this.self_lands = []; // 我方空地
    //     this.land_soilders = []; // 存储已经在战地上的士兵
    //     this.soilder_list = []; //存储菜单中的士兵
    //
    // },

    init_fight(soilder_data_list, soilder_list, target) {
        this.data_list = soilder_data_list; // 我方空地
        this.soilder_list = soilder_list;// 存储已经在战地上的士兵
        this.target = target; //存储菜单中的士兵
        this.start_select_soilder();
    },

    // 开启选择士兵到阵列的功能
    start_select_soilder () {
        cc.requireUtil.Assistant.log(this.soilder_list.length, "start_select_soilder");
        for (var i in this.soilder_list) {
            this.soilder_list[i].on(cc.Node.EventType.TOUCH_START, function (Node) {
                this.select_soilder_fun(Node.target.tag);

            }.bind(this));

            this.soilder_list[i].on(cc.Node.EventType.TOUCH_MOVE, function (event) {
                if(this.select_soilder) {
                    // 士兵随着手指移动
                    var pos =  event.getDelta();
                    this.select_soilder.x += pos.x
                    this.select_soilder.y += pos.y
                }
            }.bind(this));

            // 手指方开时
            this.soilder_list[i].on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
                cc.custom_log("==========================soilder_list  end====================");
                if(this.select_soilder) {
                    this.select_soilder.getComponent("soildder").release_hand(this.oraginPos);
                    // this.select_soilder = null;
                    if(this.soilder_list[event.target.tag]) {
                        this.soilder_list[event.target.tag].opacity = 255;
                    }

                }
            }.bind(this));

            // 手指方开时
            this.soilder_list[i].on(cc.Node.EventType.TOUCH_END, function (event) {
                cc.custom_log("==========================soilder_list  end====================");
                if(this.select_soilder) {
                    this.select_soilder.getComponent("soildder").release_hand(this.oraginPos);
                    // this.select_soilder = null;
                    this.soilder_list[event.target.tag].opacity = 255;
                }
            }.bind(this));
        }
    },

    select_soilder_fun(tag) {
        var id = parseInt(tag);
        cc.custom_log(id, "start_select_soilder id ", "fighting_map");
        this.target.set_selectt_menu_soilder_id(id);

        // cc.requireUtil.Assistant.log(this.soilder_list, "select_soilder");
        var node = this.soilder_list[id];
        // cc.custom_log(node);
        node.opacity = 140;


        var pos = cc.p(node.x  + node.y)
        var pos1 = this.node.convertToNodeSpaceAR(pos);
        var soilderSpr = cc.requireUtil.Assistant.get_soldier_by_type(1, 1);
        var soilder = cc.instantiate(this.prefab_soilder);
        var data = this.data_list[id];
        soilder.getComponent("soildder").init_data(data);

        soilder.setPosition(pos1);
        soilder.target = this.target;
        soilder.y += 50;

        this.node.addChild(soilder);
        // 保存触摸事件的士兵
        this.select_soilder = soilder;
        // 保存被选中的菜单栏的士兵的id
        // this.selectt_menu_soilder_id = id;
        // 记录原始位置
        this.oraginPos = pos1;
        // cc.custom_log(pos + "   " + pos1);
    },

    soilder_touch_start (soilder_node) {

    }


    // start () {
    //
    // },

    // update (dt) {},
});



cc.Class({
    extends: cc.Component,

    properties: {
        sprite_body: { // 自身图像
            default: null,
            type: cc.Sprite
        },

        label_soilder_num: { // 军队的数目
            default: null,
            type: cc.Label
        }
    },
    init_menu_soilder (data) {
        cc.custom_log(data, "init_menu_soilder");
        this.sprite_body.spriteFrame = cc.requireUtil.Assistant.get_soldier_by_type(data.type, 1);
        this.label_soilder_num.string = "123";
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    // start () {
    //
    // },

    // update (dt) {},
});

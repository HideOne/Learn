
cc.Class({
    extends: cc.Component,

    properties: {
        sprite_body: {
            default: null,
            type: cc.Sprite
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.is_in_land = false; // 是否在land上
        this.seat_num = 0;

        this.node.opacity = 140;
        this.start_touch();
    },

    init_data(data) {
        this.sprite_body.spriteFrame = cc.requireUtil.Assistant.get_soldier_by_type(data.type, data.level);
    },

    
    onCollisionEnter (other) {
        // console.log("=======================zhuang=====================");
        this.is_in_land = true;
        this.node.opacity = 255;
    },

    onCollisionExit (other) {
        this.is_in_land = false;
        this.node.opacity = 140;
    },

    onCollisionStay: function (other) {
        this.is_in_land = true;
        this.node.opacity = 255;
    },

    onExit () {
        this.node.targetOff(this);
        this.node.destroy();
    },

    release_hand(pos, cmd = 1) {
        if(this.is_in_land) {
            if(this.node.target) {
                cc.custom_log("==============release_hand===========");
                this.node.target.set_soilder_seat(this.node, cmd);
            }
        } else {
            if(cmd === 1) {
                this.move_and_destroy(pos);
            } else {
                this.move_orgin_pos();
            }

        }

    },

    move_orgin_pos () {
        cc.custom_log("==============move_orgin_pos=============");
        // var move = cc.moveTo(0.1, this.oraginPos);
        // cc.custom_log(this.orginPos)
        // cc.custom_log(this.node);
        // this.node.runAction(move);
        // 将此节点加到 原来父节点上
        if(this.parent_node) {
            cc.custom_log("================move_orgin_pos  ndoe->parent is null===========");
            this.node.removeFromParent(false);
            this.parent_node.addChild(this.node);
        }
        this.node.x = 0;
        this.node.y = 0;
        cc.custom_log(this.node.x + "        " + this.node.y);
    },

    move_and_destroy(pos) {
        var move = cc.moveTo(0.2, pos);
        var _this = this;
        var afterFun = cc.callFunc(function () {
            _this.onExit();
        })

        this.node.runAction(cc.sequence(move, afterFun));
    },

    set_seat_id (id) {
        this.seat_num = parseInt(id) + 1;
    },

    get_seat_id () {
        return this.seat_num - 1
    },

    start_touch () {
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            cc.custom_log("======================start touch pos============");
            this.orginPos = cc.p(event.target.x, event.target.y);
            this.parent_node = this.node.parent;
            this.select_soilder_fun(this.orginPos);

        }.bind(this));

        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
                // 士兵随着手指移动
                var pos =  event.getDelta();
                this.node.x += pos.x
                this.node.y += pos.y
        }.bind(this));

        this.node.on(cc.Node.EventType.TOUCH_END, function (event) {
            cc.custom_log("==========================soilder  end====================");
            this.node.opacity = 255;
            if(this.orginPos) {
                this.release_hand(this.orginPos, 2);
            }
        }.bind(this));
    },

    get_oragin_parent () {
        return this.parent_node;
    },

    select_soilder_fun (orginPos) {
        var main_target = this.node.target
        var node = this.node;
        node.opacity = 140;

        var world_pos = this.node.parent.getPosition();
        cc.custom_log(world_pos, "select_soilder_fun");

        this.node.removeFromParent(false);
        // 将士兵添加到  主节点上  让他有最高 zindex;
        main_target.node.addChild(node);
        node.setPosition(world_pos);
        // 转化位子

        // var pos = cc.p(node.x  + node.y)
        // var pos1 = this.node.convertToNodeSpaceAR(pos);
    }

    // start () {
    //
    // },

    // update (dt) {},
});

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html


var list = [
     {
        user_name: "古德里安",
        time_level: 7,
        power: 600,
    },
    {
        user_name: "隆美尔",
        time_level: 9,
        power: 700,
    },
    {
        user_name: "曼斯坦因",
        time_level: 5,
        power: 200,
    }
]
//==========================================

cc.Class({
    extends: cc.Component,

    properties: {

        enemys: [ //要显示的敌人
            cc.Node,
        ],
        label_refresh_price: { // 刷新需要的金币
            default: null,
            type: cc.Label
        },
        label_zhengca_price: { // 侦查需要的钻石
            default: null,
            type: cc.Label
        }



    },


    onLoad () {
        // 提前加载资源
        // cc.requireUtil.Assistant.load_prefab("prefabs/BattlefieldLayout");

        this.node.on(cc.Node.EventType.TOUCH_END, function () {});
        this.list = list;
        this.init_every_enemy();
    },

    init_every_enemy () {
        for (var i in this.enemys) {
            this.enemys[i].getComponent("enemy").init_data(list[i]);
            this.enemys[i].tag = i;
        }
    },

    onExit () {
        this.node.targetOff(this);
        this.node.destroy();
    },
    // 刷新
    onRefresh () {
        this.list = [];
      //=====
        for (var i = 0; i < 3; i++) {
            var n = Math.round(Math.random()*2)
            this.enemys[i].getComponent("enemy").init_data(list[n]);
            this.list.push(list[n]);
        }

      //=====
    },

    // 侦查
    onDetect () {
        for (var i in this.enemys) {
            this.enemys[i].getComponent("enemy").show_power();
        }
    },

    // 选择敌人
    onSelectEnemy (node) {

        // this.enemys[i]
        if(!cc.requireUtil.Assistant.one_menu_touch(1, this)) {
            return false;
        }
        var dex = node.target.tag
        if(dex < 0) {
            cc.requireUtil.Assistant.log(dex, "onSelectEnemy");
            return;
        }
        this.enemys[dex].getComponent("enemy").onSelect();
    },

    // 配置防御阵型
    onSetDefense () {
        // var fun = function (node) {
        //     node.getComponent("BattlefieldLayer").set_modal(2);
        // }
        cc.requireUtil.Assistant.add_prefab_2_Node("prefabs/setFightLayout", this.node);
    }

});

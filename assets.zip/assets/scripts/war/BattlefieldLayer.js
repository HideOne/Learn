
//测试数据
var list = [
    {
        type: 1,
        number: 100,
    },
    {
        type: 2,
        number: 100,
    },
    {
        type: 3,
        number: 100,
    }

]
//=========

cc.Class({
    extends: cc.Component,

    properties: {
        Prefab_soilder_select: { // 排兵选择栏的 框
            default: null,
            type: cc.Prefab
        },
        scrollor: {
            default: null,
            type: cc.ScrollView
        },
        prefab_soilder: { // 拖动的士兵
            default: null,
            type: cc.Prefab
        },
        node_fight_map: { //战场节点
            default: null,
            type: cc.Node
        },

        self_lands: [cc.Node], //己方空地
        enemy_lands: [cc.Node] // 敌方空地

    },

    // LIFE-CYCLE CALLBACKS:

    // modal 1.进攻时   2.防守时
    set_modal(modal = 1) {
        this.modal = modal
        cc.custom_log(modal, "set_modal");
    },

    onLoad () {
        // cc.requireUtil.Assistant.load_prefab("prefabs/warResuiltLayout");
        this.soilder_list = []; // 存储菜单士兵
        this.land_soilders = []; // 存储已经在战地上的士兵
        this.select_soilder = null // 被选中的士兵
        this.selectt_menu_soilder_id = -1; // 被选中的菜单栏士兵的id



        this.node.on(cc.Node.EventType.TOUCH_END, function () {});
        this.add_soilder_select();
        this.init_fight_map();

        // this.start_select_soilder();
        // cc.requireUtil.Assistant.log(soilder, "onLoad");
    },
    // start () {
    //     this.check_modal();
    // },
    

    onFight () {
        cc.requireUtil.Assistant.add_prefab_2_Node("prefabs/warResuiltLayout", this.node);
    },
    init_fight_map () {
        this.node_fight_map.getComponent("fighting_map").init_fight(list, this.soilder_list, this);
    },

    // 设置士兵所在的位子的坐标值
    // 外部调用
    external_set_select_land(tag) {
        this.select_land_id = parseInt(tag);
        cc.custom_log(tag, "==================external_set_select_land================");
    },

    external_get_select_land (){
        return this.select_land_id;
    },

    set_selectt_menu_soilder_id (id) {
        this.selectt_menu_soilder_id = id;
    },

    get_selectt_menu_soilder_id () {
        return this.selectt_menu_soilder_id;
    },

    // 士兵落子
    // cmd == 1 时表示从下方菜单栏 选入士兵
    set_soilder_seat (node, cmd = 1) {

            // cc.custom_log(this.select_land_id, "set_soilder_seat");
            //var node = cc.instantiate(this.select_soilder)
            // var node = this.select_soilder
        var change_soilder = this.self_lands[this.select_land_id].getChildByName("soilder");
        var node_target = node.getComponent("soildder")
        var land_id = node_target.get_seat_id();

        if(cmd === 1) {
            // 如果下方有东西
            if(change_soilder) {
                cc.custom_log("下方有兵");
                node_target.move_and_destroy();
                return;
            }
            node.removeFromParent(false);
            node.name = "soilder";
            // this.select_soilder.getComponent("soildder").onExit();
            this.self_lands[this.select_land_id].addChild(node);
            node.x = 0;
            node.y = 0
            this.remve_soilder_from_scollor(this.selectt_menu_soilder_id);
            // cc.custom_log(node.x + "   " + node.y, "set_soilder_seat");

            // 设置士兵的信息 将士兵存储在数组中
            this.land_soilders.push(node);
            // node.seat_id = this.select_land_id;
            node.getComponent("soildder").set_seat_id(this.select_land_id);
            // this.node_fight_map.getComponent("fighting_map").soilder_touch_start(node);
        } else {

            cc.log_warning(land_id, "my land_id ");
            cc.log_warning(this.select_land_id, "select_land_id ");

            //  士兵的位子没有变化时
            if(this.select_land_id === land_id) {
                cc.custom_log("=============位置没有变化=============");
                node_target.move_orgin_pos();
            } else if(change_soilder){ // 下方为其他棋子时
                cc.custom_log("=============下方有兵===========");
                this.soilder_seat_change(node, 2, change_soilder)
            } else {  // 下方为空地时
                cc.custom_log("=============下方为空地=============");
                node_target.set_seat_id(this.select_land_id);
                this.soilder_seat_change(node, 1)
            }
        }

            // this.soilder_touch(node);
    },

    soilder_seat_change (node, cmd = 1, change_soilder) {
        if(cmd === 1) {
            node.removeFromParent(false);
            this.self_lands[this.select_land_id].addChild(node);
            node.x = 0;
            node.y = 0;
        } else if(cmd === 2) {
            // 先把两个节点的父节点保存   然后对换父节点
            var node_target = node.getComponent("soildder");
            var other_target = change_soilder.getComponent("soildder");
            var other_land = change_soilder.parent;
            var current_land = node_target.get_oragin_parent();

            var node_land_id = node_target.get_seat_id();
            var other_land_id = other_target.get_seat_id();

            // 交换位置的id
            node_target.set_seat_id(other_land_id);
            other_target.set_seat_id(node_land_id);

            if(!current_land) {
                cc.log_error("current_land is null", "soilder_seat_change", "battlefiedLayer");
                return;
            }
            node.removeFromParent(false);
            change_soilder.removeFromParent(false);

            other_land.addChild(node);
            current_land.addChild(change_soilder);
            node.setPosition(cc.p(0, 0));
            change_soilder.setPosition(cc.p(0, 0));
        }

    },


    // 添加选择士兵
    add_soilder_select () {
        // var soilder = cc.requireUtil.Assistanexternal_set_select_landt.get_soldier_by_type(1, 0);
        //为每一块地编号
        for(var i in this.self_lands) {
            this.self_lands[i].tag = i;
            this.self_lands[i].target = this;
        }

        for(var i in list) {
            var node = cc.instantiate(this.Prefab_soilder_select);
            node.getComponent("menu_soilder").init_menu_soilder({type: list[i].type, level:1, number:100});
            node.x = 80 + i * 120;
            this.scrollor.content.addChild(node);

            node.tag = i;
            this.soilder_list.push(node);
        }
    },



    // // 开启选择士兵到阵列的功能
    // start_select_soilder () {
    //     cc.requireUtil.Assistant.log(this.soilder_list.length, "start_select_soilder");
    //     for (var i in this.soilder_list) {
    //         this.soilder_list[i].on(cc.Node.EventType.TOUCH_START, function (Node) {
    //             this.select_soilder_fun(Node.target.tag);
    //
    //         }.bind(this));
    //
    //         this.soilder_list[i].on(cc.Node.EventType.TOUCH_MOVE, function (event) {
    //             if(this.select_soilder) {
    //                 // 士兵随着手指移动
    //                 var pos =  event.getDelta();
    //                 this.select_soilder.x += pos.x
    //                 this.select_soilder.y += pos.y
    //             }
    //         }.bind(this));
    //
    //         // 手指方开时
    //         this.soilder_list[i].on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
    //             cc.custom_log("==========================soilder_list  end====================");
    //             if(this.select_soilder) {
    //                 this.select_soilder.getComponent("soildder").release_hand(this.oraginPos);
    //                 // this.select_soilder = null;
    //                 if(this.soilder_list[event.target.tag]) {
    //                     this.soilder_list[event.target.tag].opacity = 255;
    //                 }
    //
    //             }
    //         }.bind(this));
    //
    //         // 手指方开时
    //         this.soilder_list[i].on(cc.Node.EventType.TOUCH_END, function (event) {
    //             cc.custom_log("==========================soilder_list  end====================");
    //             if(this.select_soilder) {
    //                this.select_soilder.getComponent("soildder").release_hand(this.oraginPos);
    //                // this.select_soilder = null;
    //                 this.soilder_list[event.target.tag].opacity = 255;
    //             }
    //         }.bind(this));
    //     }
    // },

    // 从scrollor里移除 士兵
    remve_soilder_from_scollor (id) {
        cc.custom_log(typeof id, "remve_soilder_from_scollor  of  id");
        this.soilder_list[id].destroy();
        // cc.custom_log(this.soilder_list, "remve_soilder_from_scollor");
        for(var i = parseInt(id) + 1; i < this.soilder_list.length; i++) {
            cc.custom_log(i, "remve_soilder_from_scollor");
            this.soilder_list[i].x -= this.soilder_list[i].width;
            this.soilder_list[i].tag -= 1;
        }
        this.soilder_list.splice(id, 1);
        // cc.custom_log(this.soilder_list, "remve_soilder_from_scollor");
    },



    //


    // // 在地上的士兵开启触摸
    // soilder_touch (node) {
    //     for(var i in this.land_soilders) {
    //         this.land_soilders[i].tag = i;
    //     }
    //
    //     node.on(cc.Node.EventType.TOUCH_START, function (Node) {
    //
    //     });
    //
    //     this.soilder_list[i].on(cc.Node.EventType.TOUCH_MOVE, function (event) {
    //
    //     });
    //
    //     // 手指方开时
    //     node.on(cc.Node.EventType.TOUCH_CANCEL, function (event) {
    //
    //
    //     });
    //
    //     // 手指方开时
    //     node.on(cc.Node.EventType.TOUCH_END, function (event) {
    //         cc.custom_log(this.get_seat_id(), "soilder_touch", "BattlefieldLayer");
    //     });
    // },




    // start () {
    //
    // },

    // update (dt) {},
});

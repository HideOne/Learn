/**
 * Created by Administrator on 2018/7/27.
 */
var Assistant = require('assistant');

var obj = {
    Assistant : Assistant
}

cc.requireUtil = obj;
'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        cloud_right: cc.Node,
        cloud_left: cc.Node,
    },

    onLoad () {

    },

    loadScene (sceneName, showCloud) {
        this._sceneName = sceneName;
        this._showCloud = showCloud;

        if (!this._showCloud) {
            cc.director.loadScene (this._sceneName);
            return;
        } else {
            this.closeCloud ();
        }
    },
    onExit () {
      this.node.targetOff(this);
      this.destroy();
    },
    // 云彩关闭
    closeCloud() {

        var self = this;
        this.node.active = true;
        this.cloud_left.setPosition(-this.cloud_left.height, - this.cloud_left.width / 2);
        this.cloud_right.setPosition(this.cloud_right.height,  this.cloud_right.width / 2);

        var a1 = cc.moveTo (0.1, cc.p(0, 0));
        var a2 = cc.moveTo (0.1, cc.p(0, 0));

        var call = cc.callFunc (function () {
            this.openCloud();
        }, this);
        this.cloud_left.runAction(a1);
        this.cloud_right.runAction(cc.sequence(a2, cc.delayTime(0.3), call));
    },
    // 云彩打开
    openCloud() {
        var self = this;
        // cc.requireUtil.Assistant.log("call fun success", "scale_and_move_action")
        // if (this._showCloud) {
        //     this._showCloud = false;
        //     return;
        // }
        cc.requireUtil.Assistant.log(" fun openCloud success", "openCloud")
        this.node.active = true;
        this.cloud_left.setPosition(cc.p (0, 0));
        this.cloud_right.setPosition(cc.p (0, 0));

     	var a1 = cc.moveTo (0.7, cc.p(-this.cloud_left.height, - this.cloud_left.width / 2));
        var a2 = cc.moveTo (0.7, cc.p(this.cloud_right.height,  this.cloud_right.width / 2));

        var call = cc.callFunc (function () {
            // self.node.active = false;
            self.onExit();
        });
        this.cloud_left.runAction(a1);
        this.cloud_right.runAction(cc.sequence(a2, call));
    },
});

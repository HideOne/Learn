var assistant = {}
module.exports = assistant;


var debug_level = 0

cc.custom_log = function (info = "", funcName = "",  fileName = "") {
    if(debug_level < 1) {
        if(funcName || fileName) {
            console.log("============== LOG: " + fileName + " at " + "func " + funcName + "===========" );
        }
        console.log(info);
    }
}

cc.log_warning = function (info = "", funcName = "",  fileName = "") {
    if(debug_level < 2) {
        if (funcName || fileName) {
            console.log("============== WARNING: " + fileName + " at " + "func " + funcName + "===========");
        }
        console.log(info);
    }
}

cc.log_error = function (info = "", funcName = "",  fileName = "") {
    if(debug_level < 3) {
        if (funcName || fileName) {
            console.log("============== ERROR:" + fileName + " at " + "func " + funcName + "===========");
        }
        console.log(info);
    }
}

/**
 * 加载网络图片
 *
 * @param headImageUrl
 * 返回spite  失败返回空
 */
assistant.set_net_Image = function(headImageUrl, defaut_head_spriteFrame, head_Sprite) {
    // assistant.log(headImageUrl, "load_head_Image");
    var imageUrl = assistant.change_Pic_Url(headImageUrl)
    assistant.log(imageUrl);
    if(imageUrl) {
       cc.loader.load({url: imageUrl, type: 'jpg'}, function (err, texture) {
           if(texture) {
               var sprite = new cc.SpriteFrame(texture);
               head_Sprite.spriteFrame = sprite;
               return sprite;
           } else {
               head_Sprite.spriteFrame = defaut_head_spriteFrame | head_Sprite.spriteFrame;
           }
       })
    }
}

/**
 * 
 * @param {*} imageUrl 
 * 如果 imageUrl为空返回空   不是以图片后缀结尾的 加上图片后缀
 */
assistant.change_Pic_Url = function (imageUrl) {
    if(!imageUrl) {
        return null;
    }

    var url = imageUrl;
    var isPic = imageUrl.search(".*(.jpg|.png|.gif)$")
    if(isPic < 0) {
        url = imageUrl + "?1.png"
    }

    return url;

};



assistant.log = function (info = "", funcName = "",  fileName = "") {
    if(debug_level < 1) {
        if (funcName || fileName) {
            console.log("==============" + fileName + " at " + "func " + funcName + "===========");
        }
        console.log(info);
    }
}


assistant.load_local_Image = function (url){
    if(!url) {
        return;
    }

    assistant.log("待完善....", "load_local_Image");

}

assistant.set_sex = function (sexSprite, sexType) {
    console.log("============set_sex=============");
}

/**
 *
 * @param prefabUrl
 * @param targeNode  新节点的父节点
 * @param func(newNode)     参数为新节点
 */

assistant.add_prefab_2_Node = function (prefabUrl, targeNode = cc.director.getScene(), func = null, zIndex=0) {
    // console.log("============add_prefab_2_Node==========");
    var prefab = cc.loader.getRes(prefabUrl, cc.Prefab);
    if(prefab) {
        // console.log();
        cc.log_warning("===========prefab exsit==========");
        var newNode = cc.instantiate(prefab);
        if(func) {
            func(newNode);
        }
        targeNode.addChild(newNode, zIndex);
    } else {
        // console.log("===========prefab not  exsit==========");
        cc.log_warning("===========prefab not exsit==========");
        cc.loader.loadRes(prefabUrl, cc.Prefab, function (err, prefab){
            if(err){
                console.log(err);
            }else {
                var newNode = cc.instantiate(prefab);
                targeNode.addChild(newNode, zIndex);
                if(func) {
                    func(newNode);
                }
            }
        });
    }


}

/**
 * 加载预制资源 如果内存中有就返回  没有就加载且返回null
 * @param prefabUrl
 * @returns {any}
 */
assistant.load_prefab = function (prefabUrl) {
    // cc.loader.loadRes("atlas/main", cc.SpriteAtlas,function(completeCount, totalCount, res){
    var prefab = cc.loader.getRes(prefabUrl, cc.Prefab);
    if(prefab) {
        return prefab;
    }
    cc.loader.loadRes(prefabUrl, cc.Prefab, function (err, prefab){
        if(err){
            console.log(err);
        }else {
            assistant.log("prefabUrl load success", "load_prefab");
        }
    })
    return null;
}

// 将等级转化为时代等级
assistant.level_2_timestr = function (level = 0) {
    var _level = level
    if(level > 10) {
        _level = 0;
        assistant.log("没有对应时代", "level_2_timestr");
    }
    var romeNums = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
    var str = "罗马时代" + romeNums[_level];
    return str;
}

// 超过8个字符的中文 为...代替
assistant.str_leave_8 = function (str) {
    // assistant.log(str, "str_leave_8");
    var ret = str;
    if(str.length > 8) {
        ret = str.substring(0, 7) + "...";
    }
    return ret;
}

//
/**
 *避免多个按钮同时点击
 *
 * time_Sec_reset  恢复按钮的时间 <=0不恢复
 * 返回 false 表示不能点击  返回true  可以
 */
assistant.one_menu_touch = function (time_Sec_reset, target) {
    if(target._isClick) {
        return false;
    }
    target._isClick = true;
    // console.log("=========" + target._isClick)
    target.scheduleOnce(function () {
        target._isClick = false;
    }, time_Sec_reset);
    return true;
}

assistant.open_cloud = function (target, call_fun) {
    var func = function (newNode) {
        assistant.log("=======open_cloud  call=========");
        newNode.getComponent("CloudView").closeCloud();
        if(call_fun) {
            call_fun.bind(target)();
        }
        // target.scheduleOnce(function () {
        //     newNode.getComponent("CloudView").closeCloud();
        // }, 1);

    }
    assistant.add_prefab_2_Node("prefabs/CloudView", cc.director.getScene(), func, 2);
}

/**
 *  通过type和等级 获取 士兵
 * @param type
 * @param level
 * @returns {cc.SpriteFrame}
 */
assistant.get_soldier_by_type = function (type = 1, level) {
    var atlas = cc.loader.getRes("atlas/hero", cc.SpriteAtlas);
    if(!atlas) {
        cc.log_error("have no atlas", "get_soldier_by_type");
        return null;
    }
    var name = "servant_head_" + (1170 + type);
    // assistant.log(name, "get_soldier_by_type");
    var spr = atlas.getSpriteFrame(name);
    if(!spr) {
        cc.log_error("have no sprite", "get_soldier_by_type");
        return null;
    }

    // console.log(spr);
    return spr;
}



